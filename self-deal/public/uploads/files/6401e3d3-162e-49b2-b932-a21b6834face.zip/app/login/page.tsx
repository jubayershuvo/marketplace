import LoginPage from "@/components/LoginPage";

export default function Login() {
    return <LoginPage />;
}