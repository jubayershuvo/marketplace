import UsersManagement from "@/components/Users";

export default function UsersPage() {
    return (
        <UsersManagement />
    );
}