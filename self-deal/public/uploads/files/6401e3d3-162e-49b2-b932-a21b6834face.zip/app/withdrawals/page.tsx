import WithdrawManager from "@/components/Withdawals";

export default function WithdrawalsPage() {
  return <WithdrawManager />;
}
