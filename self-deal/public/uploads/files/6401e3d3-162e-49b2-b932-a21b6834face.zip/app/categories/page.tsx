import CategoryManager from "@/components/CategoryManager";

export default function CategoriesPage() {
    return <CategoryManager />;
}